
package blockchain;

public class BlockChain {

    public static void main(String[] args) {
        
        Block obj =new Block();
        obj.setVisible(true);
         
        
    }
    
}
